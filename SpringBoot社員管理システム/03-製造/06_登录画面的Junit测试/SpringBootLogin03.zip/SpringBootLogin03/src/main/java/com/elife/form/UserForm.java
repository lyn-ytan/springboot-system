package com.elife.form;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserForm {
	// 必須入力
	//@NotEmpty(message="ユーザIDを入力してください")
	//メッセージソースからメッセージを取得
	@NotEmpty(message="{login.error.accountId.notEmpty}")
	//有効なメールアドレスを入力
	//@Email(message="有効なメールアドレスを入力してください")
	//メッセージソースからメッセージを取得
	@Email(message="{login.error.accountId.isEmail}")
	private String accountId;
	//必須入力
	//@NotEmpty(message="パスワードを入力してください")
	//メッセージソースからメッセージを取得
	@NotEmpty(message="{login.error.password.notEmpty}")
	//パスワード欄に6桁半角英数字を入力
	//@Size(min=6,max=6,message="パスワード欄に6桁半角英数字を入力してください")
	//メッセージソースからメッセージを取得
	@Size(min=6,max=6, message="{login.error.password.length}")
	private String password;
}