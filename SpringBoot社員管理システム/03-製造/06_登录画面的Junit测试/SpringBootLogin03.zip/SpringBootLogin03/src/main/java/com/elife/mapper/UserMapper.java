package com.elife.mapper;
import org.apache.ibatis.annotations.Mapper;
import com.elife.bean.LoginUser;
//UserMapperインターフェースの定義
@Mapper
public interface UserMapper {
	//Mapperインターフェースにはオブジェクトを操作するためのSQL文の対応付けとSQL実行のメソッド
	//accountIdよりloginUserテーブルからデータを取得するSQL実行メソッド
	//@Select("SELECT accountId, password FROM LoginUser WHERE accountId = #{accountId}")
    public LoginUser find(String accountId);
}
