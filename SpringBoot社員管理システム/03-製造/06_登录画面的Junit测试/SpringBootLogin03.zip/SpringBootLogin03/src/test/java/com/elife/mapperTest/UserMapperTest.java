package com.elife.mapperTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.elife.SpringBootLoginApplicationTests;
import com.elife.bean.LoginUser;
import com.elife.mapper.UserMapper;

public class UserMapperTest extends SpringBootLoginApplicationTests {

		@Autowired
		private UserMapper userMapper;
		
       //ユーザーIDが存在する
		@Test
		public void testQueryUser1() {
			LoginUser user = userMapper.find("111@abc.com");
			assertEquals("111@abc.com", user.getAccountId());
			assertEquals("000001", user.getPassword());
		}
		//ユーザーIDが存在しない
		@Test
		public void testQueryUser2() {
			LoginUser user = userMapper.find("1@abc.com");
			assertEquals(null, user);
		}
	}

