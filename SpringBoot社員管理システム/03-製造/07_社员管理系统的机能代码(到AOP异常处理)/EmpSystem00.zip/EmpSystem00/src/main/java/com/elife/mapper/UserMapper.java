package com.elife.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.elife.bean.LoginUser;
//ログインユーザー検索インターフェースを定義する
@Mapper
public interface UserMapper {
	//ログインユーザー検索メソッドを定義する
	public LoginUser find(String accountId);
}
