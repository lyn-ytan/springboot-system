package com.elife.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.elife.bean.EmpData;
import com.elife.form.EmpForm;

public interface EmpService {
	//社員情報一覧
	public List<EmpData> listEmp();
	
	//keyWordで社員情報を検索
	public List<EmpData> searchEmp(String keyWord);
	
	//社員番号で社員の詳細情報を取得
	public EmpData getEmpData(String empCd);
	
	//社員情報をデータベースに登録
	public void insertEmp(EmpForm empForm);
	
	//社員情報を変更
	public void changeEmp(EmpForm empForm);
	
	//社員情報を削除
	public void deleteEmp(String empCd);
}


