package com.elife.service;

import java.util.ArrayList;
import java.util.Locale;

import org.springframework.stereotype.Service;

import com.elife.form.UserForm;

public interface UserService {
	public ArrayList<String> getResult(UserForm userForm, Locale locale) ;	
}
