package com.elife.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elife.bean.Nationality;
import com.elife.mapper.NationalityMapper;


 // NationalityServiceインターフェースを実装する
@Service
public class NationalityServiceImp implements NationalityService{
	//NationalityMapper を注入する
	@Autowired
	private NationalityMapper  nationalityMapper;
	
	//国籍リストを取得
	public List<Nationality> getNationalityList(){
		//NationalityMapper.getNationalityLisを呼出し、国籍一覧を取得する
		return nationalityMapper.getNationalityList();
	}
}
