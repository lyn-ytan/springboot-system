package com.elife.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elife.bean.EmpData;
import com.elife.bean.Gender;
import com.elife.bean.Nationality;
import com.elife.form.EmpForm;
import com.elife.service.EmpService;
import com.elife.service.GenderService;
import com.elife.service.NationalityService;

@Controller
public class ChangeController {
	@Autowired
	private NationalityService nationalityService;
	@Autowired
	private GenderService genderService;
	@Autowired
	private EmpService empService;
	@Autowired
	HttpSession session;

	@PostMapping("/toChangeEmp")
	public String toChangeEmp(@RequestParam(value = "empCd") String empCd, @ModelAttribute("form") EmpForm empForm) {
		// 社員番号で社員情報を取得
		EmpData empData = empService.getEmpData(empCd);
		// 社員情報empDataより、empFormを設定する
		empForm.setEmpCd(empData.getEmpCd());
		empForm.setName(empData.getName());
		empForm.setBirthday(empData.getBirthday().toString());
		empForm.setNationalityCd(empData.getNationality().getNationalityCd());
		empForm.setGenderCd(empData.getGender().getGenderCd());
		// 国籍一覧を取得する
		List<Nationality> nationalityList = nationalityService.getNationalityList();
		// 国籍一覧をsessionに入れる
		session.setAttribute("nationalityList", nationalityList);
		
		// 性別一覧を取得する
		List<Gender> genderList = genderService.getGenderList();
		// 性別一覧をsessionに入れる
		session.setAttribute("genderList", genderList);
		//社員情報変更画面へ遷移
		return "empChange";
	}

	@PostMapping("/changeEmp")
	public String changeEmp(@ModelAttribute("form")  @Valid EmpForm empForm, BindingResult result,
	@RequestParam(value="empCd") String empCd, Model model) {		
		if (result.hasErrors()) {
			List<ObjectError> errorList = result.getAllErrors();
			model.addAttribute("errorList", errorList);
			//toChangeEmp(empCd, empForm);
			return "empChange";
		}else {		
			empService.changeEmp(empForm);
			return "redirect:/empList";
		}
}
}