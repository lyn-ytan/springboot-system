package com.elife.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.elife.bean.Gender;

//GenderServiceインターフェースを定義する
public interface GenderService {	
	    //getGenderListメソッドを定義する
		public List<Gender> getGenderList();
}
