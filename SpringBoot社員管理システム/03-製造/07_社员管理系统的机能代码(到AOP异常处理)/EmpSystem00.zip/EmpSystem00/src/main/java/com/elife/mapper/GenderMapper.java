package com.elife.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.elife.bean.Gender;
@Mapper
public interface GenderMapper {
	public List<Gender> getGenderList();
}
