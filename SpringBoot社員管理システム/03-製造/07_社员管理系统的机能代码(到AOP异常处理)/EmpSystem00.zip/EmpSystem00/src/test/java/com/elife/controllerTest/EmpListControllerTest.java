
package com.elife.controllerTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


import java.util.Locale;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.elife.EmpSystem00ApplicationTests;
import com.elife.controller.EmpListController;


public class EmpListControllerTest extends EmpSystem00ApplicationTests {
	//モックDI
	@Autowired
	@InjectMocks
	private EmpListController empListController;	

	MockMvc mockMvc;
	//モックの設定
	@BeforeEach
	public void setUp() {
		mockMvc = MockMvcBuilders.standaloneSetup(empListController).build();
	}
	
   //ユーザーIDとパスワードが正しい、ログイン成功
	@Test
	public void testEmpListSuccess() throws Exception {
		MockHttpServletRequestBuilder getRequest = MockMvcRequestBuilders.get("/empList");
	
		ResultActions results = mockMvc.perform(getRequest);
		results.andDo(print());
		//期待の結果はエラーなし
		results.andExpect(model().errorCount(0));
		//期待の結果はempList画面に遷移
		results.andExpect(view().name("empList0"));
		results.andReturn();

	}
	
}
