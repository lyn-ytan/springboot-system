package com.elife.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.elife.bean.LoginUser;
import com.elife.form.UserForm;
import com.elife.service.UserService;

//ログインコントロールの定義
@Controller
public class LoginController {
	// サービスクラスのインターフェースに対する依存性の注入
	@Autowired
	private UserService userService;
	
	// URL「http://localhost:8080/login」へgetメソッドでリクエスト時に実行されるHandlerメソッド
	@GetMapping( "/login")
	//新規formオブジェクト、且つModelに追加する	
	public String login(@ModelAttribute("form") UserForm form, Model model) {
		//login.htmlファイルに遷移
		return("login");
	}
	
	//ユーザIdとパスワードの検証
	// 「http://localhost:8080/auth」へpostメソッドでリクエスト時に実行されるHandlerメソッド
	@PostMapping( "/auth")
	//Modelからformオブジェクトを取得、且つ検証し、検証結果をresultに入れる
	public String auth(@ModelAttribute("form") @Valid UserForm userForm, BindingResult result, Model model) {
		String url = null;
		// 検証結果がエラーがある場合
		if (result.hasErrors()) {
			// すべてのエラーメッセージを検証結果から取得する
			List<ObjectError> errorList = result.getAllErrors();
			// すべてのエラーメッセージをModelに入れる
			model.addAttribute("errorList", errorList);
			// 画面遷移login.htmlの指定
			url = "login";
			//login.htmlファイルに遷移
			return url;
		}

		List<String> errorlist = userService.getResult(userForm);
		if (!(errorlist.size() == 0)) {
			model.addAttribute("message", errorlist.get(0));
			// 画面遷移login.htmlの指定
			url = "login";
			return url;
		} else {
			// 画面遷移の指定
			url = "success";
			//success.htmlファイルに遷移
			return url;
		}
	}
}