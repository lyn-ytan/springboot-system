package com.elife.form;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserForm {
	// 必須入力
	@NotEmpty(message="ユーザIDを入力してください")
	//有効なメールアドレスを入力
	@Email(message="有効なメールアドレスを入力してください")
	private String accountId;
	//必須入力
	@NotEmpty(message="パスワードを入力してください")
	//パスワード欄に6桁半角英数字を入力
	@Size(min=6,max=6,message="パスワード欄に6桁半角英数字を入力してください")
	private String password;
}