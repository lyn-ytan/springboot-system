package com.elife.service;

import java.util.ArrayList;
import com.elife.form.UserForm;

//サービスクラスのインターフェースを作成
public interface UserService {	
      //public LoginUser find(String accountId);
	  //userFormはパラメーターとして、検索のメッセージ戻り値として、メソッドを定義する
      public ArrayList <String> getResult (UserForm uerForm);
}
