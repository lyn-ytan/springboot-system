package com.elife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpSystem00Application {

	public static void main(String[] args) {
		SpringApplication.run(EmpSystem00Application.class, args);
	}

}
