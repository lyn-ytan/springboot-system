package com.elife.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elife.bean.Gender;
import com.elife.mapper.GenderMapper;
@Service
public class GenderServiceImp implements GenderService{	
	//GenderMapper を注入する
	@Autowired
	private GenderMapper genderMapper;	
	//性別一覧を取得する
	public List<Gender> getGenderList(){
		//GenderMapper.getGenderList()を呼出し、性別一覧を取得する
		return genderMapper.getGenderList();
	}
}
