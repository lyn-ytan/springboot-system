package com.elife.service;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.elife.bean.EmpData;
import com.elife.form.EmpForm;

public interface EmpService {
	//社員情報一覧
	public List<EmpData> listEmp();
	
	//keyWordで社員情報を検索
	public List<EmpData> searchEmp(String keyWord);
	
	//社員番号で社員の詳細情報を取得
	public EmpData getEmpData(String empCd);
	
	//社員情報をデータベースに登録
	public void insertEmp(EmpForm empForm);
	
	//社員情報を変更
	public void changeEmp(EmpForm empForm);
	
	//社員情報を削除
	public void deleteEmp(String empCd);
	
	//社員情報をダウンロード
	public void empListExcel(HttpServletResponse response, List<EmpData> empList) throws IOException;
	
}


