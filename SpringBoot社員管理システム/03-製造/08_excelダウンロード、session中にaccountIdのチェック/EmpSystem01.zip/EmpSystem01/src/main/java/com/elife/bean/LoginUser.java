package com.elife.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginUser {
	private  String accountId;	
	private  String password;	
}
