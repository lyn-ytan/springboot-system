package com.elife.form;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class EmpForm {
	@NotEmpty(message = "{empCode.notEmpty}")
	private String empCd;
	
	@NotEmpty(message = "{empName.notEmpty}")
	@Pattern(regexp = "^[一-龥 ア-ン あ-ん a-z A-Z]*$", message = "{empName.error}")
	private String name;

	@NotEmpty(message = "{empBirthday.notEmpty}")
	private String birthday;
	
	@NotEmpty(message = "{nationality.notEmpty}")
	private String nationalityCd;
	
	@NotEmpty(message = "{empGender.notEmpty}")
	private String genderCd;
	
}
