
package com.elife.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Nationality {
	private String nationalityCd;
	private String nationalityName;
}
