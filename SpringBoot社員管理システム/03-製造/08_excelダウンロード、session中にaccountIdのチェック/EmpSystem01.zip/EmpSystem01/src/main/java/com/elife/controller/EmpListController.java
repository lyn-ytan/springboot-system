package com.elife.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.elife.bean.EmpData;
import com.elife.service.EmpService;

@Controller
@ComponentScan({"service"})
public class EmpListController {
	@Autowired
	private EmpService empService;
	
	//excelファイルをダウンロードするため
	@Autowired
	private HttpSession session;

	//社員情報一覧
	@GetMapping("/empList")
	public String listEmp(Model model) {
		//全ての社員情報検索
		List<EmpData> empList = empService.listEmp();
		//検索結果empListをModelに追加
		model.addAttribute("empList",empList);
		//excelファイルをダウンロードするため、検索結果empListをSessionに追加
		session.setAttribute("empList",empList);
		//社員情報一覧画面に遷移する
		return "empList";
		//return "empList0";
	}
	
	//keyWordで社員情報検索
	@GetMapping("/searchEmp")	
	//画面から入力するkeyWordをリクエストパラメータとして受け取る
	public String searchEmp(@RequestParam(value="keyWord") String keyWord,Model model) {
		//keyWordで社員情報検索
		List<EmpData> empList = empService.searchEmp(keyWord);
		//検索結果empListをModelに追加
		model.addAttribute("empList",empList);	
		//excelファイルをダウンロードするため、検索結果empListをSessionに追加
		session.setAttribute("empList",empList);
		//社員情報一覧画面に遷移する
		return "empList";
	}
	
	//社員詳細情報を表示
	@GetMapping("/showDetails")
	public String showDetails(@RequestParam(value="empCd")String empCd,Model model) {
		//社員番号で社員情報を取得
		EmpData empData = empService.getEmpData(empCd);
		//取得結果を詳細画面にModelに追加
		model.addAttribute("empData",empData);
		//社員情報一覧画面に遷移する
		return "empDetails";
	}
	
	@RequestMapping("/deleteEmp")
	public String deleteEmp(@RequestParam(value="empCd")String empCd) {		
		empService.deleteEmp(empCd);				
		return "redirect:/empList";
	}
	
	// **********************************************************
	// 社員情報のエクセルエクスポート機能
	// **********************************************************
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/empListExcel")
	// ページから渡したのリスポンス
	public void empListExcel(HttpServletResponse response) throws IOException {		
		List<EmpData> empList = (List<EmpData>) session.getAttribute("empList");

		// エクセルを生成する
		empService.empListExcel(response, empList);
	}

}
