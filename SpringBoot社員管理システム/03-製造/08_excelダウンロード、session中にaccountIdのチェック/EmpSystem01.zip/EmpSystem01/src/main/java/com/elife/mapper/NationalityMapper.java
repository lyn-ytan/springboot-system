package com.elife.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.elife.bean.Nationality;

@Mapper
public interface NationalityMapper {
	public List<Nationality> getNationalityList();
}
