package com.elife.controller;

import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.elife.bean.EmpData;
import com.elife.bean.Gender;
import com.elife.bean.Nationality;
import com.elife.form.EmpForm;
import com.elife.service.EmpService;
import com.elife.service.GenderService;
import com.elife.service.NationalityService;
import com.elife.service.NationalityServiceImp;

@Controller
@ComponentScan({"service"})
public class AddEmpController {
	@Autowired
	private NationalityService nationalityService;
	@Autowired
	private GenderService genderService;
	@Autowired
	private EmpService empService;	
	@Autowired
	private MessageSource messageSource;
	
	  @Autowired
	  HttpSession session; 

	// 新規登録画面へ遷移
	@GetMapping(value = "/toAddEmp")
	public String toAddEmp(@ModelAttribute("form") EmpForm form, Model model) {
		// 国籍一覧を取得
		List<Nationality> nationalityList = nationalityService.getNationalityList();
		// 国籍一覧をSessionに追加
		session.setAttribute("nationalityList", nationalityList);
		// 国籍一覧をModelに追加
		//model.addAttribute("nationalityList", nationalityList);

		// 性別一覧を取得
		List<Gender> genderList = genderService.getGenderList();
		// 性別一覧をSessionに追加
		session.setAttribute("genderList", genderList);
		// 性別一覧をModelに追加
		//model.addAttribute("genderList", genderList);
		// 新規登録画面へ遷移
		return ("addEmp");
	}

	// 社員情報登録
	@PostMapping( "/addEmp")
	public String addEmp(@ModelAttribute("form") @Valid EmpForm empForm, BindingResult result, 
				Model model, Locale locale) {		
		//	社員情報登録フォームの検証結果にはエラーがある場合
		if (result.hasErrors()) {
			//社員情報フォームの検証結果から全てのエラーを取得
			List<ObjectError> errorList = result.getAllErrors();
			// エラーメッセージのリストをModelに入れる
			model.addAttribute("errorList", errorList);
			// 性別のリストを取得
			//List<Gender> genderList = genderService.getGenderList();
			// 性別のリストをModelに入れる
			//model.addAttribute("genderList", genderList);
			// 国籍のリストを取得
			//List<Nationality> nationalityList = nationalityService.getNationalityList();
			// 国籍のリストをModelに入れる
			//model.addAttribute("nationalityList", nationalityList);
			// 社員情報登録画面へ遷移
			return ("addEmp");
		} else {
            //	社員情報登録フォームの検証結果にはエラーがない場合、社員番号より社員情報を取得
			EmpData empData = empService.getEmpData(empForm.getEmpCd());
			//この社員番号が既に登録した場合
			if (empData != null) {
				//エラーメッセージをModelに入れる
				model.addAttribute("message", messageSource.getMessage("addEmp.error", null, locale));
				// 性別のリストを取得
				//List<Gender> genderList = genderService.getGenderList();
				// 性別のリストをModelに入れる
				//model.addAttribute("genderList", genderList);
				// 国籍のリストを取得
				//List<Nationality> nationalityList = nationalityService.getNationalityList();
				// 国籍のリストをModelに入れる
				//model.addAttribute("nationalityList", nationalityList);
				// 社員情報登録画面へ遷移
				return ("addEmp");
			} else {
				// 社員情報をデータベースに登録
				empService.insertEmp(empForm);
				// 社員情報一覧画面へ遷移
				return ("redirect:/empList");
			}
		}
	}
}
