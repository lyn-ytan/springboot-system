package com.elife.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

//ポイント１：@Aspect
@Aspect
@Component
public class LogAspect {	
	  // ポイント２：AOPの実装
	/*
	 * @Before("execution(* *..*.*Controller.*(..))") public void startLog(JoinPoint
	 * jp) { System.out.println("メソッド開始： " + jp.getSignature()); }
	 * 
	 * // ポイント２：AOPの実装
	 * 
	 * @After("execution(* *..*.*Controller.*(..))") public void endLog(JoinPoint
	 * jp) { System.out.println("メソッド終了： " + jp.getSignature()); }
	 */
	//ポイント：Bean名で指定
	//@Around("bean(∗Controller)")
	//ポイント：@annotaion
	//@Around("@annotation(org.springframework.web.bind.annotation.GetMapping)")
	// ポイント：@within	
	  //@Around("@within(org.springframework.stereotype.Controller)")
	  //ポイント１：@Around *
	
	//@Around("execution(* *..*.*Controller.*(..))")
	/*public Object startLog(ProceedingJoinPoint jp) throws Throwable {
	  System.out.println("メソッド開始： " + jp.getSignature()); try { // ポイント２：メソッド実行
	  Object result = jp.proceed(); System.out.println("メソッド終了： " +
	  jp.getSignature()); return result; } catch (Exception e) {
	  System.out.println("メソッド異常終了： " + jp.getSignature()); e.printStackTrace();
	  throw e; } }*/
	 
	 

	/**
	 * コントローラークラスのログ出力用アスペクト.
	 */
	/*
	 * @Around("@within(org.springframework.stereotype.Controller)") public Object
	 * startLog(ProceedingJoinPoint jp) throws Throwable {
	 * System.out.println("メソッド開始： " + jp.getSignature()); try { // ポイント２：メソッド実行
	 * Object result = jp.proceed(); System.out.println("メソッド終了： " +
	 * jp.getSignature()); return result;
	 * 
	 * } catch (Exception e) { System.out.println("メソッド異常終了： " + jp.getSignature());
	 * e.printStackTrace(); throw e; } }
	 */
	/**
	 * Mapperクラスのログ出力用アスペクト.
	 * 
	 * @Around("execution(com.elife.mapper.*Mapper*.*(..))") public Object
	 * mapperLog(ProceedingJoinPoint jp) throws Throwable {
	 * System.out.println("メソッド開始： " + jp.getSignature()); * try { * Object result =
	 * jp.proceed(); * System.out.println("メソッド終了： " + jp.getSignature()); * return
	 * result; * } catch (Exception e) { System.out.println("メソッド異常終了： " +
	 * jp.getSignature()); e.printStackTrace(); throw e; } }
	 */
}
