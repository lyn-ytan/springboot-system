package com.elife.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Gender {
	private String genderName;
	private String genderCd;
	}
