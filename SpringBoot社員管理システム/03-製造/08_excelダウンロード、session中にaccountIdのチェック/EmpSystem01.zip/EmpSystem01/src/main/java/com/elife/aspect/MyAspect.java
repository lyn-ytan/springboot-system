package com.elife.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Aspect
@Component
public class MyAspect {
    private static Logger logger = Logger.getLogger(MyAspect.class);
    @Autowired
    private HttpSession session;
    @Around("execution(* com.elife.controller.*.*(..))")
    public Object sessionTimeOut(ProceedingJoinPoint pjp) throws IOException {
        Object result = null;
        String targetName = pjp.getTarget().getClass().getSimpleName();
        String methodName = pjp.getSignature().getName();
        logger.info("----------------実行方法-----------------");
        logger.info("Class名："+targetName+" メソッド名："+methodName);

        if(session.getAttribute("accountId")!=null){
            try {
                result = pjp.proceed();
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return result;
        } else{
            logger.debug("セッションがタイムアウトし、ログインページに戻っています");
            return "redirect:/login";
        }
    }

    @Around("@within(org.springframework.stereotype.Controller)")
    public Object startLog(ProceedingJoinPoint jp) throws Throwable {
        Object result = null;
        String targetName = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();

        System.out.println("メソッド開始： " + jp.getSignature());
        try {
            // ポイント２：メソッド実行
            logger.info("----------------実行方法-----------------");
            logger.info("Class名："+targetName+" メソッド名："+methodName);
            logger.info("メソッド終了： " + jp.getSignature());
            result = jp.proceed();
            System.out.println("メソッド終了： " + jp.getSignature());
            return result;

        } catch (Exception e) {
            logger.info("----------------実行方法-----------------");
            logger.info("Class名："+targetName+" メソッド名："+methodName);
            logger.info("メソッド異常終了： " + jp.getSignature());
            System.out.println("メソッド異常終了： " + jp.getSignature());
            e.printStackTrace();
            throw e;
        }
    }
}
