package com.elife.service;

import java.util.List;
import com.elife.bean.Nationality;

public interface  NationalityService {
	//国籍リストを取得
	public List<Nationality> getNationalityList();	
}
