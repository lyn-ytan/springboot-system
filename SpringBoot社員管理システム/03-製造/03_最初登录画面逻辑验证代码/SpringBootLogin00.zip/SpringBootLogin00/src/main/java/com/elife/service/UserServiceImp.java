package com.elife.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elife.bean.LoginUser;
import com.elife.mapper.UserMapper;

@Service
public class UserServiceImp implements UserService {
	// Mapperインターフェースに対する依存性の注入
	@Autowired
	private UserMapper userMapper;
	
	//Mapperインターフェースで定義したメソッドを呼び出しSQLを実行
    public LoginUser find(String accountId){
		return userMapper.find(accountId);
	}
}
