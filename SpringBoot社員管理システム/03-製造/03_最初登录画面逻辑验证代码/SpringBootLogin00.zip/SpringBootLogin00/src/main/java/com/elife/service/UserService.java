package com.elife.service;

import com.elife.bean.LoginUser;

//サービスクラスのインターフェースを作成
public interface UserService {	
      public LoginUser find(String accountId);
}
