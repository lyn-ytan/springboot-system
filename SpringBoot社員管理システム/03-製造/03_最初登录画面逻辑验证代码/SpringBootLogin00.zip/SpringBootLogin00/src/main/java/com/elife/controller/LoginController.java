package com.elife.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.elife.bean.LoginUser;
import com.elife.service.UserService;
//ログインコントロールの定義
@Controller
public class LoginController {
	// サービスクラスのインターフェースに対する依存性の注入
	@Autowired
	private UserService userService;
    
	// URL「http://localhost:8080/login」へgetメソッドでリクエスト時に実行されるHandlerメソッド
	@GetMapping("/login")
	public String login() {
		return("login");
	}
	
	// 「http://localhost:8080/auth」へpostメソッドでリクエスト時に実行されるHandlerメソッド
	@PostMapping("/auth")
	//@RequestParam(value = "accountId") を利用してリクエストパラメーターaccountIdの値を取得する
	//@RequestParam(value = "password") を利用してリクエストパラメーターpasswordの値を取得する
	// Modelオブジェクトの準備
	public String auth(@RequestParam(value = "accountId") String accountId,
			@RequestParam(value = "password") String password, Model model) {
		String url = null;
		String message = null;
		//リクエストパラメーターaccountIdの値より、ユーザーサービスuserServiceのfindメソッドを呼出し、ログインユーザーのデータを取得する
		LoginUser user = userService.find(accountId);
		//ログインユーザーのデータはヌルの場合
		if (user == null) {
			//エラーメッセージを設定する
			message = "不正なユーザーId";
			//エラーメッセージをmessage属性としてModelオブジェクトに追加する
			model.addAttribute("message", message);
			//エラーの場合、遷移先htmlファイル名(login)の指定
			url = "login";			
		}
		//リクエストパラメーターpasswordの値はログインユーザーデータのパスワードと一致しないの場合
		else if (!password.equals(user.getPassword())) {
			message = "不正なパスワード";
			//エラーメッセージをmessage属性としてModelオブジェクトに追加する
			model.addAttribute("message", message);
			//エラーの場合、遷移先htmlファイル名(login)の指定
			url = "login";
		} else {
			//成功の場合、遷移先htmlファイル名(success)の指定
			url = "success";
		}
		//遷移先のhtmlファイル名文字列に戻る
		return url;
	}
}
