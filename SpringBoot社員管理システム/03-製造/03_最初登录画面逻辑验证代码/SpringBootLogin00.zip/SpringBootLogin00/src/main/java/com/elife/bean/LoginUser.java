package com.elife.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter   
//loginUserテーブルに対応するエンティティ
public class LoginUser {
	//loginUserテーブルのaccoutIdに対応する
	private String accountId;
	//loginUserテーブルのpasswordに対応する
	private String password;
}
