package com.elife.service;

import java.util.ArrayList;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import com.elife.bean.LoginUser;
import com.elife.mapper.UserMapper;
import com.elife.form.UserForm;

@Service
public class UserServiceImp implements UserService {
	// Mapperインターフェースに対する依存性の注入
	@Autowired
	private UserMapper userMapper;
	
	//メッセージソースに対する依存性の注入
	@Autowired
	private MessageSource messageSource;
	
	//Mapperインターフェースで定義したメソッドを呼び出しSQLを実行
    //public LoginUser find(String accountId){
		//return userMapper.find(accountId);
	//}
	
    //UserFormのユーザーIdとパスワードをロジック検証する
    //public ArrayList<String>getResult(UserForm userForm){
	//国際化のため、Localeオブジェクトをパラメーター設定
	public ArrayList<String>getResult(UserForm userForm, Locale locale){
		//エラーメッセージの文字列リストを新規する
		ArrayList<String>errorlist = new ArrayList<String>();
    	//Mapperインターフェースで定義したメソッドを呼び出しSQLを実行する
		LoginUser user = userMapper.find(userForm.getAccountId());
		//取得データがヌルの場合
		if(user == null) {
			//errorlist.add("不正なユーザーId");
			//エラーメッセージをメッセージソースから取得、且つ国際化
			errorlist.add(messageSource.getMessage("login.message.accountId.error", null, locale));
			//userFormのpasswordの値はログインユーザーデータのパスワードと一致しないの場合
		}else if(!user.getPassword().equals(userForm.getPassword())) {
			//errorlist.add("不正なパスワード");
			//エラーメッセージをメッセージソースから取得、且つ国際化
			errorlist.add(messageSource.getMessage("login.message.password.error", null,locale));
		}
		//検証結果のエラーメッセージの文字列リストを戻り返す
		return errorlist;
	}
}
