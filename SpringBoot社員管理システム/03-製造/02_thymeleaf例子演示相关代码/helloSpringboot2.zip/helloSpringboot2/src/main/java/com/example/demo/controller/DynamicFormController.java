package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.form.MyCheckForm;
import com.example.demo.form.MyDynamicForm;
import com.example.demo.form.MyForm;
import com.example.demo.form.MyRadioForm;

@Controller
@RequestMapping("/dynamicform")
public class DynamicFormController {
	    @GetMapping
	    public String init(Model model) {
	        model.addAttribute(new MyDynamicForm());
	        return "view/dynamic_form";
	    }

	    @PostMapping(params="appendRow")
	    public String appendRow(MyDynamicForm form) {
	        form.appendRow();
	        this.printRows(form);
	        return "view/dynamic_form";
	    }

	    @PostMapping(params="removeIndex")
	    public String submit(MyDynamicForm form, @RequestParam int removeIndex) {
	        form.removeRow(removeIndex);
	        this.printRows(form);
	        return "view/dynamic_form";
	    }

	    private void printRows(MyDynamicForm form) {
	        List<MyDynamicForm.Row> rows = form.getRows();
	        for (int i = 0; i < rows.size(); i++) {
	        	MyDynamicForm.Row row = rows.get(i);
	            System.out.println("i=" + i + ", row.value=" + row.getValue());
	        }
	    }
	}


