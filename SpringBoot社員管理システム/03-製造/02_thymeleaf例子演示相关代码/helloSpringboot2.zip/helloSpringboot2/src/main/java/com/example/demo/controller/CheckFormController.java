package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.form.MyCheckForm;
import com.example.demo.form.MyForm;

@Controller
@RequestMapping("/checkform")
public class CheckFormController {
    @GetMapping
    public String init(Model model) {
        model.addAttribute(new MyCheckForm());
        return "view/check_form";
    }

    @PostMapping
    public String submit(MyCheckForm form) {   
    	 System.out.println("form.getChecked=" + form.getChecked());
        return "view/check_form";
    }
}

