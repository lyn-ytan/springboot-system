package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.form.MyCheckForm;
import com.example.demo.form.MyForm;
import com.example.demo.form.MySelectForm;

@Controller
@RequestMapping("/selectform")
public class SelectFormController {
	    @GetMapping
	    public String init(Model model) {
	        model.addAttribute(new MySelectForm());
	        return "view/select_form";
	    }

	    @PostMapping
	    public String submit(MySelectForm form) {
	        System.out.println("form.selectedValue=" + form.getSelectedValue());
	        return "view/select_form";
	    }
}

