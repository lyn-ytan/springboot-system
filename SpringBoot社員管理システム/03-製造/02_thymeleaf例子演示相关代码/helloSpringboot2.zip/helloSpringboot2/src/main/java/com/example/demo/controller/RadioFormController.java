package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.form.MyCheckForm;
import com.example.demo.form.MyForm;
import com.example.demo.form.MyRadioForm;

@Controller
@RequestMapping("/radioform")
public class RadioFormController {
	  @GetMapping
	    public String init(Model model) {
	        model.addAttribute(new MyRadioForm());
	        return "view/radio_form";
	    }

	    @PostMapping
	    public String submit(MyRadioForm form) {
	        System.out.println("form.selectedValue=" + form.getSelectedValue());
	        return "view/radio_form";
	    }
}

