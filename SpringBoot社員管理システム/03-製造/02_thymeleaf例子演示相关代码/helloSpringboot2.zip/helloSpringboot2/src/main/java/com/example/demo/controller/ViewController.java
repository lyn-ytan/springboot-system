package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.example.demo.model.Book;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {
	ArrayList<Book> bookList = new ArrayList<Book>();

	public ViewController() {
		int price = 2000;
		String title;
		String attach;
		String isbn;
		Date date =new Date();
		String dateStr;
		Book book = new Book(1, "dvd0", null, 1800, "","2020年02月5日");
		bookList.add(book);
		book = new Book(2, "dl0", null, 1000, "","2018年03月5日");
		bookList.add(book);
		book = new Book(3, "cd0", null, 1600,"", "2019年02月5日");
		bookList.add(book);

		for (int i = 4; i < 20; i++) {
			isbn = "ISN00" + i;
			price = price + 100;

			if (i % 3 == 0) {
				title = "dvd" + (i / 3);
				attach = "dvd";
			} else {
				if (i % 3 == 1) {
					attach = "dl";
					title = "dl" + (i / 3);
				} else {
					attach = "cd";
					title = "cd" + (i / 3);
				}
			}
			Calendar cal = Calendar.getInstance();
	        cal.setTime(date);
	        cal.add(Calendar.MONTH, -i);
	        date = cal.getTime();
	        dateStr = String.format("%tY年 %tm月 %td日", date, date, date);
			book = new Book(i, isbn, title, price, attach, dateStr);
			bookList.add(book);
		}
	}

	@GetMapping("/view/html")
	public String html(Model model) {
		model.addAttribute("message",
				"<h1>こんにちは</h1>" + "<span><a href='https://spring.io/projects/spring-boot/'>Spring Boot!!</a></span>");
		return "view/html";
	}

	@GetMapping("/view/format")
	public String format(Model model) {
		model.addAttribute("name", "山田");
		return "view/format";
	}

	@GetMapping("/view/attr")
	public String attr(Model model) {
		model.addAttribute("url", "https://www.coderbar.com/");
		return "view/attr";
	}

	@GetMapping("/view/link")
	public String link() {
		return "view/link";
	}

	@GetMapping("/view/bool")
	public String bool() {
		return "view/bool";
	}

	@GetMapping("/view/classappend")
	public String classappend() {
		return "view/classappend";
	}

	@GetMapping("/view/alttitle")
	public String alttitle() {
		return "view/alttitle";
	}

	@GetMapping("/view/each_seq")
	public String each_seq() {
		return "view/each_seq";
	}

	@GetMapping("/view/fragment")
	public String fragment(Model model) {
		model.addAttribute("msg", "こんにちは、世界！");
		return "view/fragment";
	}

	@GetMapping("/view/fragment_id")
	public String fragment_id(Model model) {
		model.addAttribute("msg", "こんにちは、世界！");
		return "view/fragment_id";
	}

	@GetMapping("/view/fragment_param")
	public String fragment_param(Model model) {
		model.addAttribute("msg", "こんにちは、世界！");
		return "view/fragment_param";
	}

	@GetMapping("/view/fragment_meta")
	public String fragment_meta(Model model) {
		model.addAttribute("msg", "こんにちは、世界！");
		return "view/fragment_meta";
	}

	@GetMapping("/view/master")
	public String master(Model model) {
		model.addAttribute("title", "共通レイアウト");
		model.addAttribute("lib", "view/master::lib");
		model.addAttribute("main", "view/master::main");
		return "common/layout";
	}

	@GetMapping("/view/i18n")
	public String i18n(Model model) {
		model.addAttribute("main", "view/i18n::main");
		return "common/layout";
	}

	@GetMapping("/view/comment")
	public String comment(Model model) {
		model.addAttribute("main", "view/comment:main");
		return "view/comment";
	}

	@GetMapping("/view/proto")
	public String proto(Model model) {
		model.addAttribute("main", "view/proto::main");
		return "view/proto";
	}

	@GetMapping("/view/booklist")
	public String booklist(Model model) {
		model.addAttribute("books", bookList);
		return "view/booklist";
	}

	@GetMapping("/view/list")
	public String list(Model model) {
		model.addAttribute("list", Arrays.asList("月", "火", "水", "木", "金", "土", "日"));
		return "view/list";
	}

	@GetMapping("view/map_block")
	public String mapBlock(Model model) {
		HashMap<String, String> map = new HashMap<>();
		map.put("001", "東京");
		map.put("002", "京都");
		map.put("003", "大阪");
		model.addAttribute("mapBlock", map);
		return "view/map_block";
	}
	
	@GetMapping("view/block")
	public String block(Model model) {
		HashMap<String, String> map = new HashMap<>();
		map.put("001", "東京");
		map.put("002", "京都");
		map.put("003", "大阪");
		model.addAttribute("map", map);
		return "view/block";
	}

	@GetMapping("view/flag")
	public String hello(Model model) {
		model.addAttribute("flag", true);
		return "view/flag";
	}
	
	 @GetMapping("view/object")
	    public String object(Model model) {
	        model.addAttribute("hoge", new Hoge());
	        return "view/object";
	    }
	    public static class Hoge {
	        public int publicField = 1;
	        public int publicMethod() {return 2;}
	        public int getPublicValue() {return 3;}
	    }   

	@GetMapping("/view/list_switch")
	public String list_switch(Model model) {
		model.addAttribute("books", bookList);
		return "view/list_switch";
	}

	@GetMapping("/view/list_condition")
	public String list_condition(Model model) {
		model.addAttribute("books", bookList);
		return "view/list_condition";
	}

	@GetMapping("/view/list_elvis")
	public String list_elvis(Model model) {
		model.addAttribute("books", bookList);
		return "view/list_elvis";
	}

	@GetMapping("/view/each_status")
	public String each_status(Model model) {
		// model.addAttribute("weeks", List.of("月", "火", "水", "木", "金", "土", "日"));
		model.addAttribute("weeks", Arrays.asList("月", "火", "水", "木", "金", "土", "日"));
		return "view/each_status";
	}

	@GetMapping("/view/each_block")
	public String each_block(Model model) {
		model.addAttribute("books", bookList);
		return "view/each_block";
	}
}
