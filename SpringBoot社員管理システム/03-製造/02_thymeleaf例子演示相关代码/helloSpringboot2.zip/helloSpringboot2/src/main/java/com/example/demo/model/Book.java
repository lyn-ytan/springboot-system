package com.example.demo.model;

public class Book {
    private int id;
    private String isbn;
    private String title;
    private int price;

	private String attach;
    private String dateStr;
    
    public Book(int id, String isbn, String title, int price, String attach, String dateStr) {
    	this. id = id;
    	this. isbn = isbn;
    	this. title = title;
    	this. price = price;
    	this. attach = attach;
    	this. dateStr = dateStr;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}
}