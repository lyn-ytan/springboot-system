package com.example.demo.form;

import java.util.HashMap;
import java.util.Map;

public class MySelectForm {
	 private String selectedValue;
	 public Map<String, String> options() {
	        Map<String, String> radioButtons = new HashMap<>();
	        radioButtons.put("tokyo", "東京");
	        radioButtons.put("kyoto", "京都");
	        radioButtons.put("osaka", "大阪");
	        return radioButtons;
	    }

	    public String getSelectedValue() {
	        return selectedValue;
	    }

	    public void setSelectedValue(String selectedValue) {
	        this.selectedValue = selectedValue;
	    }
}

